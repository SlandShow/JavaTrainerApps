/** Automatically generated file. DO NOT MODIFY */
package ru.samsung.itschool.mydraw;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}