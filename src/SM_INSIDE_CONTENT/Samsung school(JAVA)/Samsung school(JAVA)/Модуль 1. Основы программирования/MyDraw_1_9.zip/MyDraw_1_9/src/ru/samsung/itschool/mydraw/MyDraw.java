package ru.samsung.itschool.mydraw;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.CountDownTimer;
import android.view.View;

@SuppressLint("DrawAllocation")
public class MyDraw extends View {
	int N = 10;
	int[] x = new int[N];
	int[] y = new int[N];
	int[] vx = new int[N];
	int[] vy = new int[N];

	void fillArrayRandom(int[] a, int min, int max) {
		for (int i = 0; i < a.length; i++) {
			a[i] = (int) (Math.random() * (max - min + 1)) + min;
		}
	}

	void makeBalls() {
		fillArrayRandom(x, 0, 500);
		fillArrayRandom(y, 0, 500);
		fillArrayRandom(vx, -10, 10);
		fillArrayRandom(vy, -10, 10);
	}

	void moveBalls() {
		for (int i = 0; i < N; i++) {
			x[i] += vx[i];
			y[i] += vy[i];
		}
	}

	MyDraw(Context context) {
		super(context);

		makeBalls();

		MyTimer timer = new MyTimer();
		timer.start();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setColor(Color.BLUE);
		for (int i = 0; i < N; i++) {
			canvas.drawCircle(x[i], y[i], 20, paint);
		}
	}

	void nextFrame() {
		moveBalls();
		invalidate();
	}

	class MyTimer extends CountDownTimer {
		MyTimer() {
			super(10000, 100);
		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub
			nextFrame();

		}

		@Override
		public void onFinish() {
			// TODO Auto-generated method stub

		}

	}

}
