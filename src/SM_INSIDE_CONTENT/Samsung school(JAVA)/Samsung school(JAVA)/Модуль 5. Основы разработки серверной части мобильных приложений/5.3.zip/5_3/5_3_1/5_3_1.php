<?php
echo "<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8' />
</head>";
if (isset($_POST["lastname"]) || isset($_POST["firstname"]))
    if ($_POST["lastname"] != "" && $_POST["firstname"] != "") {
        $lastname = $_POST["lastname"];
        $firstname = $_POST["firstname"];
        $firstname = iconv('UTF-8', 'windows-1251', $firstname); // перевод кодировки нужен для того, чтобы корректно русские буквы отображались
        $firstname = substr($firstname, 0, 1);
        $firstname = iconv('windows-1251', 'UTF-8', $firstname); // перевод кодировки нужен для того, чтобы корректно русские буквы отображались
        echo $lastname . " " . $firstname . ".";
    } else
        echo "No POST data lastname or firstname";
else
    echo "
<form name='test' method='post' action=''>
<p><b>Фамилия:</b><br>
<input type='text' name='lastname' size='40'></p>
<p><b>Имя:</b><br>
<input type='text' name='firstname' size='40'></p>
<p><input type='submit' value='Отправить'></p>
</form>";


?>