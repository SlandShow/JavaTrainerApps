package com.samsung.itschool.example_5_3_2.model;

public class User {
    public String firstName;
    public String lastName;
    public String fullName;
}
