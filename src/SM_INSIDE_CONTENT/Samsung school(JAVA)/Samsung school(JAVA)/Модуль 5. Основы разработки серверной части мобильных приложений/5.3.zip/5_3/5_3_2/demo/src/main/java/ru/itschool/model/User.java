package ru.itschool.model;

/**
 * Created by raiym on 1/11/16 at 12:47 PM.
 */
public class User {
    public String firstName;
    public String lastName;

    public User(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }
}
