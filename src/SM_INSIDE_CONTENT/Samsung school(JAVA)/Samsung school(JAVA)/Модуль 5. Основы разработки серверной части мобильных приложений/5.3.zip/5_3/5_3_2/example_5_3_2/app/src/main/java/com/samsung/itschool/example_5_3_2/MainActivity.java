package com.samsung.itschool.example_5_3_2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.samsung.itschool.example_5_3_2.R;
import com.samsung.itschool.example_5_3_2.api.UserService;
import com.samsung.itschool.example_5_3_2.model.User;

import java.io.IOException;

import retrofit.Call;
import retrofit.GsonConverterFactory;
import retrofit.Response;
import retrofit.Retrofit;

public class MainActivity extends AppCompatActivity {
    private static String LOG_TAG = "MainActivity";
    private final String baseUrl = "http://192.168.72.3:8080";
    private TextView lastnameF;
    private String answerHTTP;
    private String lastnameS, firstnameS;
    private User userFromServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lastnameF = (TextView) findViewById(R.id.lastnameF);

    }


    public void sendPOST(View view) {
        EditText lastname = (EditText) findViewById(R.id.lastname);
        EditText firstname = (EditText) findViewById(R.id.firstname);

        lastnameS = lastname.getText().toString();
        firstnameS = firstname.getText().toString();

        new MyAsyncTask().execute("");
    }


    class MyAsyncTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            UserService service = retrofit.create(UserService.class);
            Call<User> call = service.fetchUser(firstnameS, lastnameS);
            try {
                Response<User> userResponse = call.execute();
                userFromServer = userResponse.body();
                Log.d(LOG_TAG, userFromServer.fullName);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            lastnameF.setText(userFromServer.fullName);
        }

    }

}








