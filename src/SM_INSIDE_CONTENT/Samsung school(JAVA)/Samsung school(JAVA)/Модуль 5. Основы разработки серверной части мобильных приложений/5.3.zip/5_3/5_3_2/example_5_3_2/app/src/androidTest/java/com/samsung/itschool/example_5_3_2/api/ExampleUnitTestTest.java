package com.samsung.itschool.example_5_3_2.api;

import junit.framework.TestCase;

/**
 * Created by YUN on 19.01.2016.
 */
public class ExampleUnitTestTest extends TestCase {

}