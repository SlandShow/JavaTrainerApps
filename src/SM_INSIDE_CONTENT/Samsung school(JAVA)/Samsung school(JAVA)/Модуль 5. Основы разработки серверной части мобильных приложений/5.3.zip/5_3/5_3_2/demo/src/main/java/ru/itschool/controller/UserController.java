package ru.itschool.controller;

import ru.itschool.model.User;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;

/**
 * Created by raiym on 1/11/16 at 12:46 PM.
 */
@RestController
@EnableAutoConfiguration
public class UserController {
    @RequestMapping(path = "/greeting/{firstName}/{lastName}", method = RequestMethod.GET)
    public User greeting(@PathVariable("firstName") String firstName, @PathVariable("lastName") String lastName) {
        return new User(firstName, lastName);
    }
}
