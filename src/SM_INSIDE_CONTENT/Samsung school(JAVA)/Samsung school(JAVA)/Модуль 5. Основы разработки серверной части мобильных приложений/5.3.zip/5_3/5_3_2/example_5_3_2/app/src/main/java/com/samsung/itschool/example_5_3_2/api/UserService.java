package com.samsung.itschool.example_5_3_2.api;

import com.samsung.itschool.example_5_3_2.model.User;

import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.Path;

public interface UserService {
    @GET("/greeting/{firstName}/{lastName}")
    Call<User> fetchUser(@Path("firstName") String firstName, @Path("lastName") String lastName);
}
