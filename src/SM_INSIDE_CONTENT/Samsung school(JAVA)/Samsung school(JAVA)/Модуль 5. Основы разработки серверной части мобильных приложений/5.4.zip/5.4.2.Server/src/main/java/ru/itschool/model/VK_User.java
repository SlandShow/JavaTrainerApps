package ru.itschool.model;


public class VK_User {
	
    public String uid;
    public String first_name;
    public String last_name;
    public String screen_name;
    public String sex;
    public String bdate;
    public String photo_big;

}
