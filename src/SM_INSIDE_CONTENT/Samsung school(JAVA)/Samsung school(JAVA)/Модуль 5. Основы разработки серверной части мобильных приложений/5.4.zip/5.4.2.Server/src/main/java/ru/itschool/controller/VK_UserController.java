package ru.itschool.controller;


import ru.itschool.model.VK_User;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;


@RestController
@EnableAutoConfiguration
public class VK_UserController {
    @RequestMapping(path = "/VK", method = RequestMethod.POST)
    public @ResponseBody String VK(@RequestBody VK_User vkUser) 
    {
    	System.out.println(vkUser.first_name + " " + vkUser.last_name);
    	 return vkUser.first_name + " " + vkUser.last_name;

    }
    

}
