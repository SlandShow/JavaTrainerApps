package ru.myitschool.oauth_vk.model;


public class VkUser {
    public String uid;
    public String first_name;
    public String last_name;
    public String screen_name;
    public String sex;
    public String bdate;
    public String photo_big;
}
