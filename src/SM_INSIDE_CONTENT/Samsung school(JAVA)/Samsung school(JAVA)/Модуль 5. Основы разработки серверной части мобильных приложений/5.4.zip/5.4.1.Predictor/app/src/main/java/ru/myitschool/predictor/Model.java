package ru.myitschool.predictor;

public class Model {

    public boolean endOfWord;
    public int pos;
    public String[] text;

}
