package com.example.revad.myapplicationgl;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends AppCompatActivity {

    private GLSurfaceView mGLSurfaceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ActivityManager activityManager = (ActivityManager)
                getSystemService(Context.ACTIVITY_SERVICE);
        final ConfigurationInfo configurationInfo =
                activityManager.getDeviceConfigurationInfo();
        final boolean supportsEs2 = configurationInfo.reqGlEsVersion >= 0x20000;
        if (supportsEs2) {
            mGLSurfaceView = new GLSurfaceView(this);
            mGLSurfaceView.setEGLContextClientVersion(2);
            mGLSurfaceView.setRenderer(new NewRenderer());
        } else {
            return;
        }
        setContentView(mGLSurfaceView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mGLSurfaceView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mGLSurfaceView.onPause();
    }
}

class NewRenderer implements GLSurfaceView.Renderer {
    private final FloatBuffer mTriangle1Vertices;
    private final FloatBuffer mTriangle2Vertices;
    private final FloatBuffer mTriangle3Vertices;
    private final int mBytesPerFloat = 4;
    private float[] mViewMatrix = new float[16];

    // Используется для передачи матрицы преобразований.
    private int mMVPMatrixHandle;

    // Используется для передачи информации о позиции модели.
    private int mPositionHandle;

    // Используется для передачи информации о цвете модели.
    private int mColorHandle;

    private float[] mProjectionMatrix = new float[16];
    private float[] mModelMatrix = new float[16];

    /* Выделяем массив для хранения объединеной матрицы. Она будет передана в программу шейдера. */
    private float[] mMVPMatrix = new float[16];

    // Количество элементов в вершине.
    private final int mStrideBytes = 7 * mBytesPerFloat;

    // Смещение для данных о позиции.
    private final int mPositionOffset = 0;

    // Размер данных о позиции в элементах.
    private final int mPositionDataSize = 3;

    // Смещение для данных о цвете.
    private final int mColorOffset = 3;

    // Размер данных о цвете в элементах.
    private final int mColorDataSize = 4;


    public NewRenderer() {
        final float[] triangle1VerticesData = {
                // X, Y, Z,
                // R, G, B, A
                -0.5f, -0.25f, 0.0f,
                1.0f, 0.0f, 0.0f, 1.0f,

                0.5f, -0.25f, 0.0f,
                0.0f, 0.0f, 1.0f, 1.0f,

                0.0f, 0.559016994f, 0.0f,
                0.0f, 1.0f, 0.0f, 1.0f};

        final float[] triangle2VerticesData = {
                // X, Y, Z,
                // R, G, B, A
                -0.5f, -0.25f, 0.0f,
                1.0f, 1.0f, 0.0f, 1.0f,

                0.5f, -0.25f, 0.0f,
                0.0f, 1.0f, 1.0f, 1.0f,

                0.0f, 0.559016994f, 0.0f,
                1.0f, 0.0f, 1.0f, 1.0f};

        final float[] triangle3VerticesData = {
                // X, Y, Z,
                // R, G, B, A
                -0.5f, -0.25f, 0.0f,
                1.0f, 1.0f, 1.0f, 1.0f,

                0.5f, -0.25f, 0.0f,
                0.5f, 0.5f, 0.5f, 1.0f,

                0.0f, 0.559016994f, 0.0f,
                0.0f, 0.0f, 0.0f, 1.0f};


        mTriangle1Vertices = ByteBuffer.allocateDirect(triangle1VerticesData.length
                * mBytesPerFloat).order(ByteOrder.nativeOrder()).asFloatBuffer();
        mTriangle2Vertices = ByteBuffer.allocateDirect(triangle2VerticesData.length
                * mBytesPerFloat).order(ByteOrder.nativeOrder()).asFloatBuffer();
        mTriangle3Vertices = ByteBuffer.allocateDirect(triangle3VerticesData.length
                * mBytesPerFloat).order(ByteOrder.nativeOrder()).asFloatBuffer();
        mTriangle1Vertices.put(triangle1VerticesData).position(0);
        mTriangle2Vertices.put(triangle2VerticesData).position(0);
        mTriangle3Vertices.put(triangle3VerticesData).position(0);
    }

    @Override
    public void onSurfaceCreated(GL10 glUnused, EGLConfig config) {
        GLES20.glClearColor(0.5f, 0.5f, 0.5f, 0.5f);
        final float eyeX = 0.0f;
        final float eyeY = 0.0f;
        final float eyeZ = 1.5f;

        final float lookX = 0.0f;
        final float lookY = 0.0f;
        final float lookZ = -5.0f;

        final float upX = 0.0f;
        final float upY = 1.0f;
        final float upZ = 0.0f;

        Matrix.setLookAtM(mViewMatrix, 0, eyeX, eyeY, eyeZ, lookX, lookY, lookZ,
                upX, upY, upZ);
        // Константа отвечающая за комбинацию матриц МОДЕЛЬ/ВИД/ПРОЕКЦИЯ
        final String vertexShader = "uniform mat4 u_MVPMatrix;  	\n"

                + "attribute vec4 a_Position;   \n"  //Информация о положении вершин.
                + "attribute vec4 a_Color;      \n"  //Информация о цвете вершин.
                + "varying vec4 v_Color;        \n"  //Это будет передано в фрагментный шейдер
                + "void main()                  \n"  //Начало программы вершинного шейдера
                + "{                            \n"
                //Передаем цвет для фрагментного шейдера. Он будет интерполирован
                //для всего треугольника.
                + "   v_Color = a_Color;        \n"
                //gl_Position специальная переменная, используемая для хранения конечного положения
                + "   gl_Position = u_MVPMatrix \n"
                //Умножаем вершины на матрицу для получения конечного положения
                //в нормированных координатах экрана
                + "           	* a_Position;   \n"
                + "}                            \n";


        final String fragmentShader =
                "precision mediump float;    \n"  //Устанавливаем по умолчанию среднюю
                        //точность для переменных.
                        //Максимальная точность в фрагментном
                        //шейдере не нужна.
                        + "varying vec4 v_Color;       \n"  //Цвет вершинного шейдера,
                        //интерполированный для фрагмента.
                        + "void main()                 \n"  //Точка входа для фрагментного
                        //шейдера.
                        + "{                           \n"
                        + "   gl_FragColor = v_Color;  \n"  //Передаем значения цветов напрямую
                        + "}                           \n"; //через конвейер.

        // Загрузка вершинного шейдера.
        int vertexShaderHandle = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);

        if (vertexShaderHandle != 0) {
            // Передаем в шейдер данные.
            GLES20.glShaderSource(vertexShaderHandle, vertexShader);

            // Компиляция шейреда.
            GLES20.glCompileShader(vertexShaderHandle);

            // Получаем результат компиляции.
            final int[] compileStatus = new int[1];
            GLES20.glGetShaderiv(vertexShaderHandle, GLES20.GL_COMPILE_STATUS,
                    compileStatus, 0);

            // Если компиляция не удалась, удаляем шейдер.
            if (compileStatus[0] == 0) {
                GLES20.glDeleteShader(vertexShaderHandle);
                vertexShaderHandle = 0;
            }
        }

        if (vertexShaderHandle == 0) {
            throw new RuntimeException("Error creating vertex shader.");
        }

        // Аналогичные действия выполняем с фрагментным шейдером.
        int fragmentShaderHandle = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);
        if (fragmentShaderHandle != 0) {
            // Передаем в шейдер данные.
            GLES20.glShaderSource(fragmentShaderHandle, fragmentShader);

            // Компиляция шейреда.
            GLES20.glCompileShader(fragmentShaderHandle);

            // Получаем результат компиляции.
            final int[] compileStatus = new int[1];
            GLES20.glGetShaderiv(fragmentShaderHandle, GLES20.GL_COMPILE_STATUS,
                    compileStatus, 0);

            // Если компиляция не удалась, удаляем шейдер.
            if (compileStatus[0] == 0) {
                GLES20.glDeleteShader(fragmentShaderHandle);
                fragmentShaderHandle = 0;
            }
        }

        if (fragmentShaderHandle == 0) {
            throw new RuntimeException("Error creating fragment shader.");
        }


        // Создаем программу OpenGL и получаем ссылку на него.
        int programHandle = GLES20.glCreateProgram();

        if (programHandle != 0) {
            // Подключаем вершинный шейдер к программе.
            GLES20.glAttachShader(programHandle, vertexShaderHandle);

            // Подключаем фрагментный шейдер к программе.
            GLES20.glAttachShader(programHandle, fragmentShaderHandle);

            // Подключаем атрибуты цвета и положения.
            GLES20.glBindAttribLocation(programHandle, 0, "a_Position");
            GLES20.glBindAttribLocation(programHandle, 1, "a_Color");

            // Объединяем оба шейдера в программе.
            GLES20.glLinkProgram(programHandle);

            // Проверяем статус ссылки на программу.
            final int[] linkStatus = new int[1];
            GLES20.glGetProgramiv(programHandle, GLES20.GL_LINK_STATUS,
                    linkStatus, 0);

            // Если ссылку не удалось получить, удаляем программу.
            if (linkStatus[0] == 0) {
                GLES20.glDeleteProgram(programHandle);
                programHandle = 0;
            }
        }

        if (programHandle == 0) {
            throw new RuntimeException("Error creating program.");
        }


        mMVPMatrixHandle = GLES20.glGetUniformLocation(programHandle,
                "u_MVPMatrix");
        mPositionHandle = GLES20.glGetAttribLocation(programHandle, "a_Position");
        mColorHandle = GLES20.glGetAttribLocation(programHandle, "a_Color");
        GLES20.glUseProgram(programHandle);
    }

    @Override
    public void onSurfaceChanged(GL10 glUnused, int width, int height) {
        // Устанавливаем окно OpenGL того же размера, что и поверхность экрана.
        GLES20.glViewport(0, 0, width, height);

        // Создаем новую матрицу проекции. Высота остается та же,
        // а ширина будет изменяться в соответствии с соотношением сторон.
        final float ratio = (float) width / height;
        final float left = -ratio;
        final float right = ratio;
        final float bottom = -1.0f;
        final float top = 1.0f;
        final float near = 1.0f;
        final float far = 10.0f;

        Matrix.frustumM(mProjectionMatrix, 0, left, right, bottom, top,
                near, far);
    }

    @Override
    public void onDrawFrame(GL10 glUnused) {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT | GLES20.GL_COLOR_BUFFER_BIT);

        // Делаем полный оборот при вращении за 10 секунд.
        long time = SystemClock.uptimeMillis() % 10000L;
        float angleInDegrees = (360.0f / 10000.0f) * ((int) time);

        // Рисуем первый треугольник плоскостью к нам.
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.rotateM(mModelMatrix, 0, angleInDegrees, 0.0f, 0.0f, 1.0f);
        drawTriangle(mTriangle1Vertices);

        // Рисуем второй треугольник повёрнутый параллельно земле.
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.translateM(mModelMatrix, 0, 0.0f, -1.0f, 0.0f);
        Matrix.rotateM(mModelMatrix, 0, 90.0f, 1.0f, 0.0f, 0.0f);
        Matrix.rotateM(mModelMatrix, 0, angleInDegrees, 0.0f, 0.0f, 1.0f);
        drawTriangle(mTriangle2Vertices);

        // Рисуем третий треугольник повёрнутый своей плоскостью влево.
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.translateM(mModelMatrix, 0, 1.0f, 0.0f, 0.0f);
        Matrix.rotateM(mModelMatrix, 0, 90.0f, 0.0f, 1.0f, 0.0f);
        Matrix.rotateM(mModelMatrix, 0, angleInDegrees, 0.0f, 0.0f, 1.0f);
        drawTriangle(mTriangle3Vertices);
    }

    private void drawTriangle(final FloatBuffer aTriangleBuffer) {
        // Передаем информацию о расположении.
        aTriangleBuffer.position(mPositionOffset);
        GLES20.glVertexAttribPointer(mPositionHandle, mPositionDataSize,
                GLES20.GL_FLOAT, false, mStrideBytes, aTriangleBuffer);
        GLES20.glEnableVertexAttribArray(mPositionHandle);

        // Передаем информацию о цвете.
        aTriangleBuffer.position(mColorOffset);
        GLES20.glVertexAttribPointer(mColorHandle, mColorDataSize,
                GLES20.GL_FLOAT, false, mStrideBytes, aTriangleBuffer);
        GLES20.glEnableVertexAttribArray(mColorHandle);

        // Перемножаем матрицу ВИДА на матрицу МОДЕЛИ и сохраняем результат
        // в матрицу MVP (которая теперь содержит модель*вид).
        Matrix.multiplyMM(mMVPMatrix, 0, mViewMatrix, 0, mModelMatrix, 0);

        // Перемножаем матрицу модели-вида на матрицу проекции, сохраняем
        // в MVP матрицу (которая теперь содержит модель*вид*проекцию).
        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mMVPMatrix, 0);

        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mMVPMatrix, 0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3);
    }
}
