package quest1;

import java.util.*;

public class Character {
	public int K;
	public int A;
	public int R;
	public String name;

	public Character(String name) {
		K = 1;
		A = 100;
		R = 50;
		this.name = name;
	}

}
