# Что это

UfoDestroyer - проект для демонстрации использования `SurfaceView` для создания игры для платформы Андроид. Задача игры - сбивать летающие тарелки с помощью пушки.

# Скриншот

![Игровой процесс](https://github.com/MyITschool/UfoDestroyer/raw/master/screenshot/screen.png "Игровой процесс")

# Как собирать

Убедитесь, что у вас актуальная версия Android Studio (1.3.1+). Нажмите File->New->Import Project, укажите папку с проектом.