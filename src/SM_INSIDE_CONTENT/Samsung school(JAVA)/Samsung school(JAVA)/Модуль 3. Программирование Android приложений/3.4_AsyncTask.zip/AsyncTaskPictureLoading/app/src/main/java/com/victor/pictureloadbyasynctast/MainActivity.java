package com.victor.pictureloadbyasynctast;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.URL;

public class MainActivity extends Activity {

    Button bLoad;
    ImageView imageView;
    Bitmap bitmap;
    ProgressDialog pDialog;
    private final String link = "http://www.wincore.ru/uploads/posts/2015-04/1428390721_alps.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bLoad = (Button)findViewById(R.id.button);
        imageView = (ImageView)findViewById(R.id.imageView);
        bLoad.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                new LoadImage().execute(link);
            }
        });
    }

    private class LoadImage extends AsyncTask<String, Integer, Bitmap> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Загрузка ...");
            pDialog.show();

        }
        protected Bitmap doInBackground(String... args) {
            try {
                URL url = new URL(args[0]); // Получаем url по текстовой ссылке
                InputStream stream = (InputStream)url.getContent(); //
                bitmap = BitmapFactory.decodeStream(stream);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        protected void onPostExecute(Bitmap image) {

            if(image != null){
                imageView.setImageBitmap(image);
                pDialog.dismiss();
            }else{

                pDialog.dismiss();
                Toast.makeText(MainActivity.this, "Ошибка загрузки", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }
    }

}

