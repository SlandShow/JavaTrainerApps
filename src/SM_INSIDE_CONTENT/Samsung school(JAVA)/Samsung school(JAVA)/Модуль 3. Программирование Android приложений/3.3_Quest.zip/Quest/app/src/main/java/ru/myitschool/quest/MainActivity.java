package ru.myitschool.quest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //=======персонаж=======
    public class Character {
        public int K;
        public int A;
        public int R;
        public String name;

        public Character(String name) {
            K = 1;
            A = 100;
            R = 50;
            this.name = name;
        }
    }

    //=======ситуация=======
    public class Situation {

        public Situation[] direction;
        public String subject;
        public String text;
        public int dK;
        public int dA;
        public int dR;

        public Situation (String subject, String text, int variants, int dk,int da,int dr) {
            this.subject=subject;
            this.text=text;
            dK=dk;
            dA=da;
            dR=dr;
            direction=new Situation[variants];
        }
    }

    //=======история=======
    public class Story {
        private Situation start_story;
        public Situation current_situation;
        Story() {
            start_story = new Situation("первая сделка (Windows)","Только вы начали работать и тут-же удача! Вы нашли клиента и продаете ему " + "партию ПО МС Виндовс. Ему в принципе достаточно взять 100 коробок версии HOME.\n"
                    + "(1)у клиента денег много, а у меня нет - вы выпишете ему счет на 120 коробок ULTIMATE по 50тр\n"
                    + "(2)чуть дороже сделаем, кто там заметит - вы выпишете ему счет на 100 коробок PRO по 10тр\n"
                    + "(3)как надо так и сделаем - вы выпишете ему счет на 100 коробок HOME по 5тр ",3, 0, 0, 0);
            start_story.direction[0]=new Situation("корпоратив", "Неудачное начало, ну чтож, сегодня в конторе копроратив! "
                    + "Познакомлюсь с коллегами, людей так сказать посмотрю, себя покажу", 0, 0, -10, -10);
            start_story.direction[1]=new Situation("совещание, босс доволен", "Сегодня будет совещание, меня неожиданно вызвали,"
                    + "есть сведения что \n босс доволен сегодняшней сделкой.", 0, 1, 100, 0);
            start_story.direction[2]=new Situation("мой первый лояльный клиент", "Мой первый клиент доволен скоростью и качеством "
                    + "моей работы. Сейчас мне звонил лично \nдиреткор компании и сообщил что скоро состоится еще более крупная сделка"
                    + " и он хотел чтобы по ней работал именно я!", 0, 0, 50, 1);
            current_situation=start_story;
        }
        public void go(int num) {
            if(num<=current_situation.direction.length)
                current_situation=current_situation.direction[num-1];
            else System.out.println("Вы можете выбирать из "+current_situation.direction.length+" вариантов");
        }
        public boolean isEnd(){
            return current_situation.direction.length==0;
        }
    }
    //=======игра=======
    /*public class Game {
        public static Character manager;
        public static Story story;
        public static void main(String[] args) {
            Scanner in=new Scanner(System.in);
            System.out.println("... подпись под договором (ваше имя):");
            manager =new Character(in.next());
            story = new Story();
            while (true){
                manager.A+=story.current_situation.dA;
                manager.K+=story.current_situation.dK;
                manager.R+=story.current_situation.dR;
                System.out.println("=====\nКарьера:"+manager.K+"\tАктивы:"+manager.A+"\tРепутация:"+manager.R+"\n=====");
                System.out.println("============="+story.current_situation.subject+"==============");
                System.out.println(story.current_situation.text);
                if(story.isEnd()) {System.out.println("====================the end!===================");return;}
                story.go(in.nextInt());
            }
        }
    }*/

    Character manager; // наш персонаж
    Story story; // наша история

    // в этом методе мы размещаем всю информацию, специфичную для текущей
    // ситуации на форме приложения, а также размещаем кнопки, которые 
    // позволят пользователю выбрать дальнейший ход событий
    private void updateStatus(){
    	// не забываем обновить репутацию в соответствии с новым
    	// состоянием дел
        manager.A+=story.current_situation.dA;
        manager.K+=story.current_situation.dK;
        manager.R+=story.current_situation.dR;
        // выводим статус на форму
        ((TextView) findViewById(R.id.status)).
        		setText("Карьера:"+manager.K+
                "\nАктивы:"+manager.A+"\nРепутация:"+manager.R);
        // аналогично для заголовка и описания ситуации
        ((TextView) findViewById(R.id.title)).
        	setText(story.current_situation.subject);
        ((TextView) findViewById(R.id.desc)).
        	setText(story.current_situation.text);
        ((LinearLayout) findViewById(R.id.layout)).removeAllViews();
        // размещаем кнопку для каждого варианта, который пользователь
        // может выбрать
        for (int i = 0; i < story.current_situation.direction.length; i++){
            Button b = new Button(this);
            b.setText(Integer.toString(i+1));
            final int buttonId = i; // напоминаю, что в анонимных классах
            		// можно использовать только те переменные метода,
            		// которые объявлены как final
            // создаем новый анонимный класс и устанавливаем его
            // обработчиком нажатия на кнопку
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    go(buttonId); // поскольку анонимный класс имеет полный
                    		// доступ к методам и переменным родительского,
                    		// то мы просто вызываем нужный нам метод.
                }
            });
            // добавляем готовую кнопку на разметку
            ((LinearLayout) findViewById(R.id.layout)).addView(b);
        }
    }

    // метод для перехода на нужную ветку развития
    private void go(int i){
        story.go(i+1);
        updateStatus();
        // если история закончилась, выводим на экран поздравление
        if(story.isEnd())
            Toast.makeText(this, "Игра закончена!", 
            		Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // создаем нового персонажа и историю
        manager = new Character("Вася");
        story = new Story();
        // в первый раз выводим на форму весь необходимый текст и элементы
        // управления
        updateStatus();
    }
}
