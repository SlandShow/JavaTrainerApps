package com.itschool.samsung.myadapter;

/**
 * Created by Samsung IT School on 08.12.2015.
 */

public class MyMonth {
    String month = "";   // Название месяца
    double temp = 0.;     // Средняя температура
    int days = 0;        // Количество дней
    boolean like = true; // Нравится месяц
}

