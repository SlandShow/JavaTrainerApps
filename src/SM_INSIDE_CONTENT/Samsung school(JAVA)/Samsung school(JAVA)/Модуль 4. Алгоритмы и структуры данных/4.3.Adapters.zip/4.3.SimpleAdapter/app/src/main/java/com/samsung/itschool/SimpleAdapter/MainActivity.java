package com.samsung.itschool.SimpleAdapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;


public class MainActivity extends Activity {

    // Названия месяцев
    String[] monthArr = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"};
    // Среднесуточная температура
    String[] tempArr = {"-12.7", "-11.3", "-4.5", "7.7", "19.3", "23.9", "23.5", "22.8", "16.0", "5.2", "-0.3", "-9.3"};
    // Количество дней
    String[] dayCArr = {"31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Готовим данные
        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>(monthArr.length);
        HashMap<String, Object> map;
        for (int i = 0; i < monthArr.length; i++) {
            map = new HashMap<String, Object>();
            map.put("month", monthArr[i]);
            map.put("temp", tempArr[i]);
            map.put("day", dayCArr[i]);
            map.put("like", true);
            map.put("img", R.drawable.sun);
            data.add(map);
        }
        // Атрибуты элементов
        String[] from = {"month", "temp", "day", "like", "img"};
        // Идентификаторы
        int[] to = {R.id.textView, R.id.textView2, R.id.textView3, R.id.checkBox, R.id.imageView};
        // Создание адаптера
        SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.adapter_item, from, to);

        ListView lv = (ListView) findViewById(R.id.listView);
        lv.setAdapter(adapter);
    }
}
