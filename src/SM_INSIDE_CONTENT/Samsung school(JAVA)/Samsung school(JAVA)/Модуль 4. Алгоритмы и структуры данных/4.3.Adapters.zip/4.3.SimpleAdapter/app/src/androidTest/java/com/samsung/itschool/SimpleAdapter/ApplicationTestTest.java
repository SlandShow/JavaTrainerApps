package com.samsung.itschool.SimpleAdapter;

import junit.framework.TestCase;

/**
 * Created by YUN on 08.12.2015.
 */
public class ApplicationTestTest extends TestCase {

}